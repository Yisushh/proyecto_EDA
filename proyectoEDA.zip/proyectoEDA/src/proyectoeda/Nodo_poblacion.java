package proyectoeda;
public class Nodo_poblacion {
    public Cola_poblacion poblacion;
    Nodo_poblacion sig;
    public Nodo_poblacion(Cola_poblacion poblacion) {
        this.poblacion = poblacion;
    }
}