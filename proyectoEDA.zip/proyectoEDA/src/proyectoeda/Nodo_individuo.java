package proyectoeda;


public class Nodo_individuo {
    public Lista_individuo individuo;
    Nodo_individuo sig;

    public Nodo_individuo(Lista_individuo individuo) {
        this.individuo = individuo;
    }
}