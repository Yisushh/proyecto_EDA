package proyectoeda;

public class Nodo_rasgo {
    public Rasgo rasgo;
    Nodo_rasgo sig;

    public Nodo_rasgo(Rasgo rasgo) {
        this.rasgo = rasgo;
    }
}
